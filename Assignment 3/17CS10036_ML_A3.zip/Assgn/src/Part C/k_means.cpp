#include<bits/stdc++.h>
using namespace std;
#define int long long
#define double long double 
#define endl '\n'
double data[600][8300];
clock_t time_p = clock();
void time()
{
  time_p = clock() - time_p;
  cerr << "Time elapsed : " << (double)(time_p)/CLOCKS_PER_SEC <<endl;
}
signed main()
{
	 mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());  //Random number generator
	 int num_rows=589;
	 int num_columns=8266;
	 freopen("data_set.txt","r",stdin); //Reading the input from the normalized tf idf data
	 for(int i=0;i<num_rows;i++)
	 	for(int j=0;j<num_columns;j++)
	 		cin>>data[i][j];
	 int num_clusters=8;
	 vector<int>Cluster[8];
	 vector<double>Cluster_Parameters[8];
	 set<int>p;
	 for(int i=0;i<num_clusters;i++)
	 {
	 	   int Cluster_Centre=rng()%589;  //Initalising the 8 distinct cluster centres
	 	   for(int j=0;j<num_columns;j++)
	 	   	 Cluster_Parameters[i].emplace_back(data[Cluster_Centre][j]);  //Initialising the parameters of the 8 cluster centres
	 	   p.emplace(Cluster_Centre);
	 }
	 assert((int)p.size()==8);  //Checking that we have generated 8 distinct cluster centres
	 int num_iterations=100;  //Doing iterations
	 for(int i=1;i<=num_iterations;i++)
	 {
           cout<<"Iteration Number "<<i<<" is being done now"<<endl;
           for(int i=0;i<8;i++)
           	Cluster[i].clear();
           for(int i=0;i<num_rows;i++) //For each dataset we will calculate the nearest cluster of the 8 clusters and assign it to that cluster
           {
           	      double res=-1e18;  //for finding maximum dot product(distance is inversely proportional to the dot product)
           	      int parent_cluster=-1;  //for storing the parent cluster 
           	      for(int k=0;k<num_clusters;k++)
           	      {
           	      	    double ans=0;  //computing the dot product
           	      	    for(int j=0;j<num_columns;j++)
           	      	    	ans+=data[i][j]*Cluster_Parameters[k][j];
                        ans=exp(ans); //Similarity
           	      	    if(ans>res)
           	      	    {
           	      	    	  res=ans;
           	      	    	  parent_cluster=k;
           	      	    }
           	      }
           	      Cluster[parent_cluster].emplace_back(i);  //Assigning this particular row to the parent cluster
           }
           for(int k=0;k<num_clusters;k++)
           {
           	     Cluster_Parameters[k].clear();
           	     for(int j=0;j<num_columns;j++)
           	     {
           	     	  double sum=0;  //For each parameter of each cluster we will compute the average value and assign that as the cluster
           	     	  for(int i=0;i<(int)Cluster[k].size();i++)
           	     	  	     sum+=data[Cluster[k][i]][j];
           	     	  sum/=(int)Cluster[k].size();  //Computing the average value of each parameter over each cluster
           	     	  Cluster_Parameters[k].emplace_back(sum); //Assigning that as cluster parameters
           	     }
           }
           cout<<"The size of Clusters are\n";
           for(int i=0;i<8;i++)
           	cout<<(int)Cluster[i].size()<<" ";  //
           cout<<endl;
	 }
	 freopen("k_means.txt","w",stdout); //Printing the output to k_means.txt
	 for(int i=0;i<8;i++)
	 {
	 	   int size=Cluster[i].size();
	 	   for(int j=0;j<size;j++)
	 	   {
	 	   	    cout<<Cluster[i][j];
	 	   	    if(j!=size-1)
	 	   	    	cout<<',';
	 	   }
	 	   cout<<endl;
   }
   freopen("input1_nmi.txt","w",stdout);
   for(int i=0;i<8;i++)
   {
         cout<<(int)Cluster[i].size()<<endl;
         for(int j=0;j<(int)Cluster[i].size();j++)
          cout<<Cluster[i][j]<<" ";
         cout<<endl;
   }
	 time();  
   return 0;
}
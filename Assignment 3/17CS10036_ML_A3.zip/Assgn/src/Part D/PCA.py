import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import math
import time
from sklearn.decomposition import PCA
pd.options.mode.chained_assignment = None 
df=pd.read_csv("data.csv")
df=df.drop(df.columns[0],axis='columns')
data=df.iloc[:,:].values
data=np.array(data)
data=np.float64(data)
num_rows=data.shape[0]
num_columns=data.shape[1]
for j in range(0,num_columns):
    count=0
    for i in range(0,num_rows):
    	count+=data[i][j]>0
    for i in range(0,num_rows):
        data[i][j]=1.0*data[i][j]*math.log(1.0*(1+num_rows)/(1+count))
index=-1
for i in range(0,num_rows):
	magnitude=0
	for j in range(0,num_columns):
		magnitude+=data[i][j]*data[i][j]
	magnitude=math.sqrt(magnitude)
	if(magnitude==0):
		index=i
		continue
	for j in range(0,num_columns):
		data[i][j]/=magnitude
pca=PCA(n_components=100)
data=pca.fit_transform(data)  #Doing PCA using sklearn as specified in the assignment
num_rows=data.shape[0]
num_columns=data.shape[1]
for i in range(0,num_rows):
	magnitude=0
	for j in range(0,num_columns):
		magnitude+=data[i][j]*data[i][j]
	magnitude=math.sqrt(magnitude)
	if(magnitude==0):
		continue
	for j in range(0,num_columns):
		data[i][j]/=magnitude
for i in range(0,num_rows):
	if(index==i):  #Removing the zero row
		continue
	for j in range(0,num_columns):
		print('%.9f'%data[i][j])

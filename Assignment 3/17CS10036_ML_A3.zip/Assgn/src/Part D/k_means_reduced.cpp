#include<bits/stdc++.h>
using namespace std;
#define int long long
#define double long double 
#define endl '\n'
double data[600][8300];
clock_t time_p = clock();
void time()
{
  time_p = clock() - time_p;
  cerr << "Time elapsed : " << (double)(time_p)/CLOCKS_PER_SEC <<endl;
}
signed main()
{
	 mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());  //Random number generator
	 int num_rows=589;
	 int num_columns=100;
	 freopen("pca_dataset.txt","r",stdin);
	 for(int i=0;i<num_rows;i++)
	 	for(int j=0;j<num_columns;j++)
	 		cin>>data[i][j];
	 int num_clusters=8;
	 vector<int>Cluster[8];
	 vector<double>Cluster_Parameters[8];
	 set<int>p;
	 for(int i=0;i<num_clusters;i++)
	 {
	 	   int Cluster_Centre=rng()%589;
	 	   for(int j=0;j<num_columns;j++)
	 	   	 Cluster_Parameters[i].emplace_back(data[Cluster_Centre][j]);
	 	   p.emplace(Cluster_Centre);
	 }
	 assert((int)p.size()==8);  //Checking that we have generated 8 distinct cluster centres
	 int num_iterations=100;
	 for(int i=1;i<=num_iterations;i++)
	 {
           cout<<"Iteration Number "<<i<<" is being done now"<<endl;
           for(int i=0;i<8;i++)
           	Cluster[i].clear();
           for(int i=0;i<num_rows;i++)
           {
           	      double res=-1e18;
           	      int parent_cluster=-1;
           	      for(int k=0;k<num_clusters;k++)
           	      {
           	      	    double ans=0;
           	      	    for(int j=0;j<num_columns;j++)
           	      	    	ans+=data[i][j]*Cluster_Parameters[k][j];
                        ans=exp(ans);
           	      	    if(ans>res)
           	      	    {
           	      	    	  res=ans;
           	      	    	  parent_cluster=k;
           	      	    }
           	      }
           	      Cluster[parent_cluster].emplace_back(i);
           }
           for(int k=0;k<num_clusters;k++)
           {
           	     Cluster_Parameters[k].clear();
           	     for(int j=0;j<num_columns;j++)
           	     {
           	     	  double sum=0;
           	     	  for(int i=0;i<(int)Cluster[k].size();i++)
           	     	  	     sum+=data[Cluster[k][i]][j];
           	     	  sum/=(int)Cluster[k].size();
           	     	  Cluster_Parameters[k].emplace_back(sum);
           	     }
           }
           for(int i=0;i<8;i++)
           	cout<<(int)Cluster[i].size()<<" ";
           cout<<endl;
	 }
	 freopen("k_means_reduced.txt","w",stdout);
	 for(int i=0;i<8;i++)
	 {
	 	   int size=Cluster[i].size();
	 	   for(int j=0;j<size;j++)
	 	   {
	 	   	    cout<<Cluster[i][j];
	 	   	    if(j!=size-1)
	 	   	    	cout<<',';
	 	   }
	 	   cout<<endl<<endl;
     }
   freopen("input2_nmi.txt","w",stdout);
   for(int i=0;i<8;i++)
   {
         cout<<(int)Cluster[i].size()<<endl;
         for(int j=0;j<(int)Cluster[i].size();j++)
          cout<<Cluster[i][j]<<" ";
         cout<<endl;
   }

	 time();  
     return 0;
}
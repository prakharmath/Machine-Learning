#include<bits/stdc++.h>
#define int long long
#define endl '\n'
#define double long double
using namespace std;
clock_t time_p = clock();
void time()
{
  time_p = clock() - time_p;
  cerr << "Time elapsed : " << (double)(time_p)/CLOCKS_PER_SEC <<endl;
}
/*  Row 0-45 - Buddhism(Class 1)
    Row 46-126 - TaoTeChing(Class 2)
    Row 127-288 - Upanishad(Class 3)
    Row 289-477 - YogaSutra(Class 4)
    Row 478-508 - BookofProverbs(Class 5)
    Row 509-520 - BookOfEcclesiastes(Class 6)
    Row 521-570 - BookOfEccleasiasticus(Class 7)
    Row 571-589 - BookofWisdom(Class 8)*/
signed main()  //Contains the code for calculating the NMI score of a given cluster
{
     vector<int>Class(590);
     for(int i=0;i<=44;i++)
        Class[i]=1;
     for(int i=45;i<=125;i++)
        Class[i]=2;
     for(int i=126;i<=287;i++)
        Class[i]=3;
     for(int i=288;i<=476;i++)
        Class[i]=4;
     for(int i=477;i<=507;i++)
        Class[i]=5;               //Assigning class to each index
     for(int i=508;i<=519;i++)
        Class[i]=6;
     for(int i=520;i<=569;i++)
        Class[i]=7;
     for(int i=570;i<=588;i++)
        Class[i]=8;
     freopen("input3_nmi.txt","r",stdin);  //Reading the input from the output generated in earlier parts
     vector<vector<int> >count(9,vector<int>(9,0));  //Computing the number of elements of each class in  each cluster
     for(int i=1;i<=8;i++)
     {
            int size;
            cin>>size;
            vector<int>freq(9,0);
            for(int i=0;i<size;i++)
            {
                  int x;
                  cin>>x;
                  freq[Class[x]]++;  //Computing frequency r each class in each cluster and storing them in count array
            }
            for(int j=1;j<=8;j++)
                count[i][j]=freq[j];
     }
     double entropy_class_labels=0;  //Computing the entropy of class label
     vector<int>class_frequency(9,0);  //Computing the number of elements in each class
     for(int i=1;i<=8;i++)
        for(int j=1;j<=8;j++)
            class_frequency[j]+=count[i][j];
     double sum=1.0*accumulate(class_frequency.begin(),class_frequency.end(),0LL);
     for(int i=1;i<=8;i++)
     {
          entropy_class_labels+=(-1)*(1.0*class_frequency[i]/sum)*(log2(1.0*class_frequency[i]/sum)); //Computing entropy of class labels(H(Y) in the document)
     }
     vector<int>cluster_frequency(9,0); //Computing the number of elements in each cluster
     for(int i=1;i<=8;i++)
        for(int j=1;j<=8;j++)
            cluster_frequency[i]+=count[i][j];
     double entropy_cluster_label=0;  //Computing the cluster entropy
     sum=1.0*accumulate(cluster_frequency.begin(),cluster_frequency.end(),0LL);
     for(int i=1;i<=8;i++)
     {
          entropy_cluster_label+=(-1)*(1.0*cluster_frequency[i]/sum)*(log2(1.0*cluster_frequency[i]/sum)); //Computing the cluster entropy (H(C) in the document)
     }
     double conditional_entropy=0; //Computing the conditional entropy
     for(int i=1;i<=8;i++)
     {
          double cluster_entropy=0; 
          double sum=accumulate(count[i].begin(),count[i].end(),0LL);
          for(int j=1;j<=8;j++)
            if(count[i][j]!=0)  
            cluster_entropy+=(-1)*(1.0*count[i][j]/sum)*(log2(1.0*count[i][j]/sum));  //Computing the cluster conditional entropy
          cluster_entropy*=1.0*cluster_frequency[i]/589;  //Multiplying by the probability of that particular cluster
          conditional_entropy+=cluster_entropy;
     }
     double nmi_score=2*(entropy_class_labels-conditional_entropy);
     nmi_score/=entropy_cluster_label+entropy_class_labels;
     cout<<"The nmi score of agglomerative clustering is ";
     cout.precision(10);
     cout<<nmi_score<<endl;
     time();
     return 0;
}
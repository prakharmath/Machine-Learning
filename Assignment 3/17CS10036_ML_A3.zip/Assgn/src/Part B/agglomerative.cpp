#include<bits/stdc++.h>
#define double long double
#define int long long
#define endl '\n'
using namespace std;
clock_t time_p = clock();
void time()
{
  time_p = clock() - time_p;
  cerr << "Time elapsed : " << (double)(time_p)/CLOCKS_PER_SEC <<endl;
}
double data[600][8300];  //Storing the data in 2d array
signed main()
{
     mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());  //Random number generator
	 int num_rows=589;  //Removed all zero row
	 int num_columns=8266;
	 freopen("data_set.txt","r",stdin); //Taking the input from the generated data
	 for(int i=0;i<num_rows;i++)
	 	for(int j=0;j<num_columns;j++)
	 		cin>>data[i][j];
	 vector<int>Cluster_number(num_rows);  //Storing the cluster number of a row 
	 iota(Cluster_number.begin(),Cluster_number.end(),0); //Initialising each row to a different cluster
	 vector<vector<double> >distance(num_rows,vector<double>(num_rows,-1e18)); //Storing the distance between each of the two points
	 for(int i=0;i<num_rows;i++)
	 {
	 	  for(int j=i;j<num_rows;j++)
	 	  {
	 	  	     double sum=0;
	 	  	     for(int k=0;k<num_columns;k++)  //Computing the dot product as we are using dot product as a measure of distance
	 	  	     {
	 	  	     	sum+=1.0*data[i][k]*data[j][k];
	 	  	     }  
	 	  	     distance[i][j]=distance[j][i]=exp(sum); //Computing the distance(we are storing e^z and then calculating maximum instead of storing e^-z and calculating minimum)
	 	  }
	 }
	 for(int x=0;x<num_rows-8;x++)  //As we want 8 clusters
	 {
	 	     double res=-1e18;
	 	     int near1=-1;
	 	     int near2=-1;
	 	     for(int i=0;i<num_rows;i++)
	 	     {
	 	     	  for(int j=i+1;j<num_rows;j++)
	 	     	  {
	 	     	  	   if(distance[i][j]>res&&Cluster_number[i]!=Cluster_number[j]) //As the distance is inversely proportional to dot product 
	 	     	  	   {
	 	     	  	   	    res=distance[i][j];  //We will find the max dot product clusters
	 	     	  	   	    near1=i;
	 	     	  	   	    near2=j;
	 	     	  	   }
	 	     	  }
	 	     }
	 	     int temp=Cluster_number[near2];
	 	     for(int i=0;i<num_rows;i++)  //we will club the two clusters
	 	     	if(Cluster_number[i]==temp)
	 	     		Cluster_number[i]=Cluster_number[near1];
	 }
	 set<int>p;
	 for(int i=0;i<num_rows;i++)
	 	p.insert(Cluster_number[i]);
	 vector<int>Cluster[8];  //To store the clusters
	 int index=0;
	 freopen("agglomerative.txt","w",stdout); //Printing clusters as required in the assignment
	 for(auto &x:p)
	 {
	 	  for(int i=0;i<num_rows;i++)
	 	  	if(Cluster_number[i]==x)
	 	  		Cluster[index].emplace_back(i);
      	  int size=Cluster[index].size();
      	  for(int i=0;i<size;i++)
      	  {
      	  	    cout<<Cluster[index][i];
      	  	    if(i!=size-1)
      	  	    	cout<<',';
      	  }
	 	  index++;
	 	  cout<<endl;
	 }
	 freopen("input3_nmi.txt","w",stdout);  //printing the clusters in an appropriate format so that they can be used as an input to part E
	 index=0;
	 for(auto &x:p)
	 {
	 	  for(int i=0;i<8;i++)
	 	  	Cluster[i].clear();
	 	  for(int i=0;i<num_rows;i++)
	 	  	if(Cluster_number[i]==x)
	 	  		Cluster[index].emplace_back(i);
      	  int size=Cluster[index].size();
      	  cout<<size<<endl;
      	  for(int i=0;i<size;i++)
      	  {
      	  	    cout<<Cluster[index][i]<<" ";
      	  }
	 	  index++;
	 	  cout<<endl;
	 }
     time();
     return 0;
}
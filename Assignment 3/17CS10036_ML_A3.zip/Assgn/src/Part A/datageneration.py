import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import math
import time
pd.options.mode.chained_assignment = None 
df=pd.read_csv("data.csv") #reading the data from the csv file
df=df.drop(df.columns[0],axis='columns')
data=df.iloc[:,:].values
data=np.array(data)
data=np.float64(data)   
num_rows=data.shape[0]
num_columns=data.shape[1]
for j in range(0,num_columns):  #Calculating the tf idf score for each data point using the frequency 
    count=0
    for i in range(0,num_rows):
    	count+=data[i][j]>0
    for i in range(0,num_rows):
        data[i][j]=1.0*data[i][j]*math.log(1.0*(1+num_rows)/(1+count))
index=-1
for i in range(0,num_rows):   #Normalizing each datapoint by dividing by the magnitude
	magnitude=0
	for j in range(0,num_columns):
		magnitude+=data[i][j]*data[i][j]
	magnitude=math.sqrt(magnitude)
	if(magnitude==0):  #There is a single point data point with magnitude zero or which contains an empty row
		index=i
		continue
	for j in range(0,num_columns):
		data[i][j]/=magnitude
for i in range(0,num_rows):
	if(i==index):   #Removing the zero row
		continue
	for j in range(0,num_columns):
		print('%.9f'%data[i][j])

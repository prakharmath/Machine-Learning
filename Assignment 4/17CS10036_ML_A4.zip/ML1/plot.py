import numpy as np 
import matplotlib.pyplot as plt 
n=int(input())
train_accuracy=[]
test_accuracy=[]
for i in range(n):
	a,b=map(float,input().split())
	train_accuracy.append(a)
	test_accuracy.append(b)
epochs=[]
for i in range(1,21):
	epochs.append(10*i)
train_accuracy=np.array(train_accuracy)
test_accuracy=np.array(test_accuracy)
xaxis=np.linspace(0,5,100)
plt.figure()
plt.plot(epochs,train_accuracy,label='Train Accuracy')
plt.plot(epochs,test_accuracy,label='Test Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()
plt.show()

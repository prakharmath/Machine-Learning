def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn
import numpy as np
import math
import csv
data=[]
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
with open("data.txt") as input_file:
	for line in csv.reader(input_file,dialect="excel-tab"):
		data.append(line)
data=np.array(data).astype(np.float)
y=[]
for i in range(0,210):
	y.append(int(data[i][7]))
for i in range(0,7):
	column_i=np.array(data[:,i])
	mean=np.mean(column_i)
	standard_deviation=np.std(column_i)
	for j in range(210):
		data[j][i]-=mean
		data[j][i]/=standard_deviation
data=np.delete(data,-1,axis=1)
x_train, x_test, y_train, y_test = train_test_split(data,y,train_size=0.8,test_size=0.2)
classifierf1a = MLPClassifier(solver = 'sgd', activation = 'logistic',batch_size = 32,
                    hidden_layer_sizes = (32), random_state =42,learning_rate_init = 0.01, learning_rate = 'constant', max_iter = 200)

classifierf1b = MLPClassifier(solver = 'sgd', activation = 'relu',batch_size = 32,
                    hidden_layer_sizes = (64, 32),random_state =42, learning_rate_init = 0.01, learning_rate = 'constant', max_iter = 200)
classifierf1a.fit(x_train, y_train)
classifierf1b.fit(x_train,y_train)
print("train accuracy for 1a using sklearn MLP classifier = ",100*classifierf1a.score(x_train,y_train))
print("test accuracy for 1a using sklearn MLP classifier= ",100*classifierf1a.score(x_test,y_test))
print("train accuracy for 1b using sklearn MLP classifier = ",100*classifierf1b.score(x_train,y_train))
print("test accuracy for 1b using sklearn MLP classifier = ",100*classifierf1b.score(x_test,y_test))
file=open("new_data.txt","w")
for i in range(0,168):
	for j in range(0,7):
		file.write(str(x_train[i][j]))
		file.write('\n')
	file.write(str(y_train[i]))
	file.write('\n')
for i in range(0,42):
	for j in range(0,7):
		file.write(str(x_test[i][j]))
		file.write('\n')
	file.write(str(y_test[i]))
	file.write('\n')
file.close()
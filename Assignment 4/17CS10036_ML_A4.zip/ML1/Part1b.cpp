#include<bits/stdc++.h>
#define double long double
#define int long long
#define endl '\n'
using namespace std;
clock_t time_p = clock();
void time()
{
	time_p = clock() - time_p;
	cerr << "Time elapsed : " << (double)(time_p) / CLOCKS_PER_SEC << endl;
}
double inline relu(double x)  //relu function
{
	if (x < 0)
		return 0;
	return x;
}
vector<double> inline differentiation_relu(vector<double>x) //differential of relu
{
	vector<double>res;
	for (auto &y : x)
	{
		if (y <= 0)
			res.emplace_back(0);
		else
			res.emplace_back(1);
	}
	return res;
}
vector<double> inline softmax(vector<double>&x)  //softmax function
{
	double sum = 0.0L;
	vector<double>res;
	for (auto &y : x)
		sum += exp(y);
	for (auto &y : x)
		res.emplace_back(exp(y) / sum);
	return res;
}
double inline dot_product(vector<double>&x, vector<double>&y)  //computing the dot product
{
	int n = x.size();
	assert((int)x.size() == (int)y.size());
	double res = 0.0L;
	for (int i = 0; i < n; i++)
		res += 1.0L * x[i] * y[i];
	return res;
}
void inline backward_propagation(vector<double>&x_end, vector<double>&x_middle_1, vector<double>&x_middle_2, vector<double>&X, vector<vector<double> >&weight_1, vector<vector<double> >&weight_2, vector<vector<double> >&weight_3, int Class, double learning_rate)
{
	vector<int>Y;      //backward_propagation
	if (Class == 1)
	{
		Y.emplace_back(1);
		Y.emplace_back(0);
		Y.emplace_back(0);
	}
	else if (Class == 2)
	{
		Y.emplace_back(0);
		Y.emplace_back(1);
		Y.emplace_back(0);
	}
	else
	{
		Y.emplace_back(0);
		Y.emplace_back(0);
		Y.emplace_back(1);
	}
	vector<double>derivation_cost_function;
	for (int i = 0; i < 3; i++)
		derivation_cost_function.emplace_back(x_end[i] - Y[i]);
	vector<double>x_middle_2_derivative = differentiation_relu(x_middle_2);
	vector<double>delta_1;
	for (int i = 0; i < 32; i++)
		delta_1.emplace_back(x_middle_2_derivative[i]*dot_product(weight_3[i], derivation_cost_function));
	vector<double>delta_2;
	vector<double>x_middle_1_derivative = differentiation_relu(x_middle_1);
	for (int i = 0; i < 64; i++)
		delta_2.emplace_back(x_middle_1_derivative[i]*dot_product(weight_2[i], delta_1));
	for (int i = 0; i < 32; i++)
		for (int j = 0; j < 3; j++)
			weight_3[i][j] -= learning_rate * derivation_cost_function[j] * x_middle_2[i];
	for (int i = 0; i < 64; i++)
		for (int j = 0; j < 32; j++)
			weight_2[i][j] -= learning_rate * delta_1[j] * x_middle_1[i];
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 64; j++)
		{
			weight_1[i][j] -= learning_rate * X[i] * delta_2[j];
		}
	}
	return;
}
void inline forward(vector<vector<double> >&X, vector<vector<double> >&weight_1, vector<vector<double> >&weight_2, vector<vector<double> >&weight_3, vector<int>Y, double learning_rate)
{
	int n = X.size();  //forward pass
	for (int i = 0; i < n; i++)
	{
		vector<double>x_middle1, x_middle2;
		for (int j = 0; j < 64; j++)
		{
			vector<double>temp;
			for (int i = 0; i < 7; i++)
				temp.emplace_back(weight_1[i][j]);
			x_middle1.emplace_back(relu(dot_product(temp, X[i]) + 1));
		}
		for (int j = 0; j < 32; j++)
		{
			vector<double>temp;
			for (int k = 0; k < 64; k++)
			{
				temp.emplace_back(weight_2[k][j]);
			}
			x_middle2.emplace_back(relu(dot_product(temp, x_middle1) + 1));
		}
		vector<double>x_end;
		for (int j = 0; j < 3; j++)
		{
			vector<double>temp;
			for (int i = 0; i < 32; i++)
				temp.emplace_back(weight_3[i][j]);
			x_end.emplace_back(relu(dot_product(temp, x_middle2) + 1));
		}
		x_end = softmax(x_end);
		backward_propagation(x_end, x_middle1, x_middle2, X[i], weight_1, weight_2, weight_3, Y[i], learning_rate);
	}
	return;
}
double inline test(vector<vector<double> >&weight_1, vector<vector<double> >&weight_2, vector<vector<double> >&weight_3, vector<vector<double> >&X, vector<int>Y)
{
	int n = X.size();
	int count = 0;    //testing for accuracy
	for (int i = 0; i < n; i++)
	{
		vector<double>x_middle1, x_middle2;
		for (int j = 0; j < 64; j++)
		{
			vector<double>temp;
			for (int i = 0; i < 7; i++)
				temp.emplace_back(weight_1[i][j]);
			x_middle1.emplace_back(relu(dot_product(temp, X[i]) + 1));
		}
		for (int j = 0; j < 32; j++)
		{
			vector<double>temp;
			for (int i = 0; i < 64; i++)
				temp.emplace_back(weight_2[i][j]);
			x_middle2.emplace_back(relu(dot_product(temp, x_middle1) + 1));
		}
		vector<double>x_end;
		for (int j = 0; j < 3; j++)
		{
			vector<double>temp;
			for (int i = 0; i < 32; i++)
				temp.emplace_back(weight_3[i][j]);
			x_end.emplace_back(relu(dot_product(temp, x_middle2) + 1));
		}
		x_end = softmax(x_end);
		vector<int>y;
		vector<int>x;
		if (Y[i] == 1)
		{
			y.emplace_back(1);
			y.emplace_back(0);
			y.emplace_back(0);
		}
		else if (Y[i] == 2)
		{
			y.emplace_back(0);
			y.emplace_back(1);
			y.emplace_back(0);
		}
		else
		{
			y.emplace_back(0);
			y.emplace_back(0);
			y.emplace_back(1);
		}
		if (x_end[1] > x_end[2])
		{
			if (x_end[0] < x_end[1])
			{
				x.emplace_back(0);
				x.emplace_back(1);
				x.emplace_back(0);
			}
			else
			{
				x.emplace_back(1);
				x.emplace_back(0);
				x.emplace_back(0);
			}
		}
		else
		{
			if (x_end[0] < x_end[2])
			{
				x.emplace_back(0);
				x.emplace_back(0);
				x.emplace_back(1);
			}
			else
			{
				x.emplace_back(1);
				x.emplace_back(0);
				x.emplace_back(0);
			}
		}
		int flag = 0;
		for (int i = 0; i < 3; i++)
			if (x[i] != y[i])
				flag = 1;
		if (flag == 0)
			count++;
	}
	return count * 100 * 1.0 / n;
}
signed main()
{
	freopen("new_data.txt", "r", stdin);
	vector<vector<double> >train_data, test_data;
	vector<int>train_y, test_y;
	train_data.resize(168);
	test_data.resize(42);
	for (int i = 0; i < 168; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			double x;
			cin >> x;
			train_data[i].emplace_back(x);
		}
		int x;
		cin >> x;
		train_y.emplace_back(x);
	}
	for (int i = 0; i < 42; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			double x;
			cin >> x;
			test_data[i].emplace_back(x);
		}
		int x;
		cin >> x;
		test_y.emplace_back(x);
	}
	vector<double>accuracy_train[5], accuracy_test[5];
	double final_train = 0;
	double final_test = 0;
	for (int batch = 0; batch < 5; batch++)  //batches
	{
		cout << "Batch " << batch + 1 << " running\n";
		vector<vector<double> >data_batch(32);
		vector<int>output_batch;
		for (int i = 32 * batch; i < 32 * batch + 32; i++)
		{
			for (auto &x : train_data[i])
			{
				data_batch[i - 32 * batch].emplace_back(x);
			}
			output_batch.emplace_back(train_y[i]);
		}
		vector<vector<double> >weight_1(7, vector<double>(64, 0));
		vector<vector<double> >weight_2(64, vector<double>(32, 0));
		vector<vector<double> >weight_3(32, vector<double>(3, 0));
		mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());  //seed for random number generator
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < 32; j++)
			{
				int x = rng() % 1000000000;
				weight_1[i][j] = (2.0 * x / 1000000000) - 1;  //randomly assigning weights
			}
		}
		for (int i = 0; i < 64; i++)
		{
			for (int j = 0; j < 32; j++)
			{
				int x = rng() % 1000000000;
				weight_2[i][j] = (2.0 * x / 1000000000) - 1;
			}
		}
		for (int i = 0; i < 32; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				int x = rng() % 1000000000;
				weight_3[i][j] = (2.0 * x / 1000000000) - 1;
			}
		}
		for (int epochs = 1; epochs < 201; epochs++)  //performing epochs
		{
			double learning_rate = 0.01;
			forward(data_batch, weight_1, weight_2, weight_3, output_batch, learning_rate);
			double accu_train = test(weight_1, weight_2, weight_3, data_batch, output_batch);
			double accu_test = test(weight_1, weight_2, weight_3, test_data, test_y);
			if (epochs % 10 == 0)
			{
				accuracy_train[batch].emplace_back(accu_train);
				accuracy_test[batch].emplace_back(accu_test);
			}
			cout.precision(10);
			if (epochs == 200)
			{
				final_train += accu_train;
				final_test += accu_test;
			}
		}
	}
	cout << "The final train and test accuracies are " << setprecision(10) << fixed;
	cout << final_train / 5.0 << " " << final_test / 5.0 << endl;
	freopen("graph.txt", "w", stdout);
	int n = accuracy_train[0].size();
	cout << n << endl;
	for (int i = 0; i < n; i++)
	{
		double mean_train = 0;
		double mean_test = 0;
		for (int j = 0; j < 5; j++)
		{
			mean_train += accuracy_train[j][i];
			mean_test += accuracy_test[j][i];
		}
		mean_train /= 5;
		mean_test /= 5;
		cout << mean_train << " " << mean_test << endl;
	}
	time();
	return 0;
}
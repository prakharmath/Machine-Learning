import pandas as pd 
import numpy as np 
import matplotlib as plt
import math
import pprint
from numpy import log2 as log 
from pprint import pprint
import sklearn
from sklearn.tree import DecisionTreeClassifier
eps = np.finfo(float).eps
pd.options.mode.chained_assignment = None 
df=pd.read_csv("train.csv");
y=df.quality
n=len(y)
x=[[0]*n]*11
x[0]=df.fixedacidity #Reading all the attributes one by one 
x[1]=df.volatileacidity 
x[2]=df.citricacid 
x[3]=df.residualsugar 
x[4]=df.chlorides 
x[5]=df.freeso2 
x[6]=df.totalso2 
x[7]=df.density 
x[8]=df.pH 
x[9]=df.sulphates
x[10]=df.alcohol
for i in range(0,n):
	if(y[i]<5):
		y[i]=0
	elif(y[i]==5 or y[i]==6):
		y[i]=1
	else:
		y[i]=2
for i in range(0,11): #z score normalisation
	average=0
	X=x[i]
	for p in X:
		average+=p    #Finding average of all the values for z score normalisation
	average/=n 
	standard_deviation=0
	for p in X:
		standard_deviation+=(p-average)*(p-average) #Finding the standard deviation of values for z score normalisation
	standard_deviation/=n-1
	standard_deviation=math.sqrt(standard_deviation)
	for j in range(0,n):
		X[j]=(X[j]-average)/standard_deviation  #Performing z score normalisation
	mini=min(X)
	maxi=max(X)
	difference=maxi-mini  #Dividing the values into 4 bins
	difference/=4
	for j in range(0,n):
		x[i][j]=math.floor((X[j]-mini)/difference)  #Assigning appropriate values out of {0,1,2,3} to each attribute in accordance to bins and z score
L=[]
LT=[]
for j in range(0,2*n//3):
	l=[]
	for i in range(0,11):
		l.append(int(x[i][j]))
	l.append(int(y[j]))
	L.append(l)
for j in range(2*n//3,n):
    l=[]
    for i in range(0,11):
        l.append(int(x[i][j]))
    l.append(int(y[j]))
    LT.append(l)
dataset=pd.DataFrame(L,columns=['fixedacidity','volatileacidity','citricacid','residualsugar','chlorides','freeso2','totalso2','density','pH','sulphates','alcohol','quality'])
testdataset=pd.DataFrame(LT,columns=['fixedacidity','volatileacidity','citricacid','residualsugar','chlorides','freeso2','totalso2','density','pH','sulphates','alcohol','quality'])
def entropy(Column):
    elements,counts = np.unique(Column,return_counts = True)
    m=len(elements)
    for i in range(0,m):
   		entropy = np.sum([(-counts[i]/np.sum(counts))*np.log2(counts[i]/np.sum(counts)) for i in range(len(elements))])
    return entropy
def InformationGain(data,split_attribute_name,target_name="quality"):
    total_entropy = entropy(data[target_name]) 
    vals,counts= np.unique(data[split_attribute_name],return_counts=True)
    Weighted_Entropy = np.sum([(counts[i]/np.sum(counts))*entropy(data.where(data[split_attribute_name]==vals[i]).dropna()[target_name]) for i in range(len(vals))])
    Information_Gain = total_entropy - Weighted_Entropy
    return Information_Gain
def Build_Tree(data,originaldata,features,target_attribute_name="quality",parent_node_class = None):
    if len(np.unique(data[target_attribute_name])) <= 1:
        return np.unique(data[target_attribute_name])[0]
    
    elif len(data)<10:
        return np.unique(originaldata[target_attribute_name])[np.argmax(np.unique(originaldata[target_attribute_name],return_counts=True)[1])]
    
    elif len(features) ==0:
        return parent_node_class    
    else:
        parent_node_class = np.unique(data[target_attribute_name])[np.argmax(np.unique(data[target_attribute_name],return_counts=True)[1])]
        item_values = [InformationGain(data,feature,target_attribute_name) for feature in features] #Return the information gain values for the features in the dataset
        best_feature_index = np.argmax(item_values)
        best_feature = features[best_feature_index]
        tree = {best_feature:{}}
        features = [i for i in features if i != best_feature]        
        for value in np.unique(data[best_feature]):
            value = value
            sub_data = data.where(data[best_feature] == value).dropna()
            subtree = Build_Tree(sub_data,dataset,features,target_attribute_name,parent_node_class)
            tree[best_feature][value] = subtree
        return(tree)    
Tree=Build_Tree(dataset,dataset,dataset.columns[:-1])
def predict(query,tree):
    for key in list(query.keys()):
        if key in list(tree.keys()):
            try:
                result = tree[key][query[key]] 
            except:
                return 1
            result = tree[key][query[key]]
            if isinstance(result,dict):
                return predict(query,result)
            else:
                return result
queries=testdataset.iloc[:,:-1].to_dict(orient = "records")
count=0
true_positive=0  #Calculating precision recall and accuracy wrt value 1 of quality
true_negative=0
false_positive=0
false_negative=0
P=[]
for i in range(0,n//3):
    p=predict(queries[i],Tree)
    P.append(p)
    if(p==y[i+2*n//3]):
        if(y[i+2*n//3]==1):
            true_positive+=1
        else:
            true_negative+=1
    else:
        if(p==1):
            false_positive+=1
        else:
            false_negative+=1
accuracy1=(true_positive+true_negative)/(true_positive+true_negative+false_negative+false_positive)
precision1=true_positive/(true_positive+false_positive)
recall1=true_positive/(true_positive+false_negative)
true_positive=0
true_negative=0
false_positive=0
false_negative=0  #calculating precision recall accuracy wrt value 0 of quality
for i in range(0,n//3):
    p=P[i]
    if(p==y[i+2*n//3]):
        if(y[i+2*n//3]==0):
            true_positive+=1
        else:
            true_negative+=1
    else:
        if(p==0):
            false_positive+=1
        else:
            false_negative+=1
accuracy2=(true_positive+true_negative)/(true_positive+true_negative+false_negative+false_positive)
count=0
if(true_positive+false_positive==0):
    count+=1
    precision2=0
else:
    precision2=true_positive/(true_positive+false_positive)
recall2=true_positive/(true_positive+false_negative)
true_positive=0
true_negative=0
false_positive=0  #calculating precision recall and accuracy wrt value 2 of quality 
false_negative=0
for i in range(0,n//3):
    p=P[i]
    if(p==y[i+2*n//3]):
        if(y[i+2*n//3]==2):
            true_positive+=1
        else:
            true_negative+=1
    else:
        if(p==2):
            false_positive+=1
        else:
            false_negative+=1
accuracy3=(true_positive+true_negative)/(true_positive+true_negative+false_negative+false_positive)
if(true_positive+false_positive==0):
    precision3=0
    count+=1
else:
    precision3=true_positive/(true_positive+false_positive)
recall3=true_positive/(true_positive+false_negative)
print("Macro Accuracy from self written decision tree:",(accuracy1+accuracy2+accuracy3)/3)
print("Macro Precision from self written decision tree:",(precision1+precision2+precision3)/(3))
print("Macro Recall from self written decision tree:",(recall1+recall2+recall3)/(3))
tree = DecisionTreeClassifier(criterion = 'entropy',min_samples_split=10).fit(dataset.iloc[:,:-1],y[0:2*n//3])
prediction = tree.predict(testdataset.iloc[:,:-1])
true_positive=0
true_negative=0
false_positive=0
false_negative=0
for i in range(2*n//3,n):
    p=prediction[i-2*n//3]
    if(p==y[i]):
        if(y[i]==1):
            true_positive+=1
        else:
            true_negative+=1
    else:
        if(p==1):
            false_positive+=1
        else:
            false_negative+=1
accuracy1=(true_positive+true_negative)/(true_positive+true_negative+false_negative+false_positive)
precision1=true_positive/(true_positive+false_positive)
recall1=true_positive/(true_positive+false_negative)
true_positive=0
true_negative=0
false_positive=0
false_negative=0
for i in range(2*n//3,n):
    p=prediction[i-2*n//3]
    if(p==y[i]):
        if(y[i]==0):
            true_positive+=1
        else:
            true_negative+=1
    else:
        if(p==0):
            false_positive+=1
        else:
            false_negative+=1
accuracy2=(true_positive+true_negative)/(true_positive+true_negative+false_negative+false_positive)
precision2=true_positive/(true_positive+false_positive)
recall2=true_positive/(true_positive+false_negative)
true_positive=0
true_negative=0
false_positive=0
false_negative=0
true_positive=0
true_negative=0
false_positive=0
false_negative=0
for i in range(2*n//3,n):
    p=prediction[i-2*n//3]
    if(p==y[i]):
        if(y[i]==2):
            true_positive+=1
        else:
            true_negative+=1
    else:
        if(p==2):
            false_positive+=1
        else:
            false_negative+=1
accuracy3=(true_positive+true_negative)/(true_positive+true_negative+false_negative+false_positive)
precision3=true_positive/(true_positive+false_positive)
recall3=true_positive/(true_positive+false_negative)
print("Macro Accuracy from sklearn  decision tree:",(accuracy1+accuracy2+accuracy3)/3)
print("Macro Precision from sklearn decision tree:",(precision1+precision2+precision3)/3)
print("Macro Recall from sklearn decision tree:",(recall1+recall2+recall3)/3)

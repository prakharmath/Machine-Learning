import pandas as pd 
import numpy as np 
import matplotlib as plt
import math
import pprint
from pprint import pprint
from numpy import log2 as log
import sklearn
from sklearn.tree import DecisionTreeClassifier
eps = np.finfo(float).eps
pd.options.mode.chained_assignment = None 
df=pd.read_csv("train.csv");
y=df.quality
n=len(y)
x=[[0]*n]*11
x[0]=df.fixedacidity #Reading all the attributes one by one 
x[1]=df.volatileacidity 
x[2]=df.citricacid 
x[3]=df.residualsugar 
x[4]=df.chlorides 
x[5]=df.freeso2 
x[6]=df.totalso2 
x[7]=df.density 
x[8]=df.pH 
x[9]=df.sulphates
x[10]=df.alcohol
for i in range(0,n):
	if(y[i]<5):
		y[i]=0
	elif(y[i]==5 or y[i]==6):
		y[i]=1
	else:
		y[i]=2
for i in range(0,11): #z score normalisation
	average=0
	X=x[i]
	for p in X:
		average+=p    #Finding average of all the values for z score normalisation
	average/=n 
	standard_deviation=0
	for p in X:
		standard_deviation+=(p-average)*(p-average) #Finding the standard deviation of values for z score normalisation
	standard_deviation/=n-1
	standard_deviation=math.sqrt(standard_deviation)
	for j in range(0,n):
		X[j]=(X[j]-average)/standard_deviation  #Performing z score normalisation
	mini=min(X)
	maxi=max(X)
	difference=maxi-mini  #Dividing the values into 4 bins
	difference/=4
	for j in range(0,n):
		x[i][j]=math.floor((X[j]-mini)/difference)  #Assigning appropriate values out of {0,1,2,3} to each attribute in accordance to bins and z score
L=[]
for j in range(0,n):
	l=[]
	for i in range(0,11):
		l.append(int(x[i][j]))
	l.append(int(y[j]))
	L.append(l)
dataset=pd.DataFrame(L,columns=['fixedacidity','volatileacidity','citricacid','residualsugar','chlorides','freeso2','totalso2','density','pH','sulphates','alcohol','quality'])
def entropy(Column): #Calculating the entropy for the given column
    elements,counts = np.unique(Column,return_counts = True)
    m=len(elements)
    for i in range(0,m):
   		entropy = np.sum([(-counts[i]/np.sum(counts))*np.log2(counts[i]/np.sum(counts)) for i in range(len(elements))])
    return entropy
def InformationGain(data,split_attribute_name,target_name="quality"): #Calculating the information gain based on the given split attribute
    total_entropy = entropy(data[target_name]) 
    vals,counts= np.unique(data[split_attribute_name],return_counts=True)
    Weighted_Entropy = np.sum([(counts[i]/np.sum(counts))*entropy(data.where(data[split_attribute_name]==vals[i]).dropna()[target_name]) for i in range(len(vals))])
    Information_Gain = total_entropy - Weighted_Entropy
    return Information_Gain
def Build_Tree(data,originaldata,features,target_attribute_name="quality",parent_node_class = None):
    if len(np.unique(data[target_attribute_name])) <= 1:  #if the class if fully pure simply return the only class
        return np.unique(data[target_attribute_name])[0]
    
    elif len(data)<10:  #If we have less than 10 points in the given dataset return the most frequent quality value in the dataset
        return np.unique(originaldata[target_attribute_name])[np.argmax(np.unique(originaldata[target_attribute_name],return_counts=True)[1])]
    
    elif len(features) ==0:
        return parent_node_class    
    else:
        parent_node_class = np.unique(data[target_attribute_name])[np.argmax(np.unique(data[target_attribute_name],return_counts=True)[1])]
        item_values = [InformationGain(data,feature,target_attribute_name) for feature in features] #Return the information gain values for the features in the dataset
        best_feature_index = np.argmax(item_values)  #Computing the best feature from information gain nd its inddex
        best_feature = features[best_feature_index]
        tree = {best_feature:{}}  #Building a new node for our newly calculated new feature
        features = [i for i in features if i != best_feature]         
        for value in np.unique(data[best_feature]): #Iterating over the best feature to recursively build the tree
            value = value
            sub_data = data.where(data[best_feature] == value).dropna() #dropping the dummy column created
            subtree = Build_Tree(sub_data,dataset,features,target_attribute_name,parent_node_class) #recursively building the tree
            tree[best_feature][value] = subtree
        return(tree)    
Tree=Build_Tree(dataset,dataset,dataset.columns[:-1]) #Calling the function to build our decision tree
def predict(query,tree):  #Recursively traversing the three in inorder fashion to predict the attribute
    for key in list(query.keys()):
        if key in list(tree.keys()):
            try:
                result = tree[key][query[key]] 
            except:
                return 1
            result = tree[key][query[key]]
            if isinstance(result,dict):
                return predict(query,result)
            else:
                return result
queries=dataset.iloc[:,:-1].to_dict(orient = "records")  #Assimilating the queries
count=0
for i in range(0,n):  #Predicting the accuracy of the self written decision tree
	if(predict(queries[i],Tree)==y[i]):
		count+=1
print("The accuracy from self written decision tree on the training set is ",100*count/n,"%")
tree = DecisionTreeClassifier(criterion = 'entropy',min_samples_split=10).fit(dataset.iloc[:,:-1],y)
prediction = tree.predict(dataset.iloc[:,:-1])
count=0
for i in range(0,n):  #Predicting the accuracy of sklearn decision tree
	count+=prediction[i]==y[i]
print("The accuracy from sklearn decision tree on the training set is ",100*count/n,"%")


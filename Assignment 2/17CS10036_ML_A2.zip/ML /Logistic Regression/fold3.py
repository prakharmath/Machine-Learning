import pandas as pd 
import numpy as np 
import matplotlib as plt
import math
import time
from sklearn import metrics 
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
pd.options.mode.chained_assignment = None 
df=pd.read_csv("train.csv");
y=df.quality
n=len(y)
x=[[0]*n]*11
x[0]=df.fixedacidity #Reading all the attributes one by one 
x[1]=df.volatileacidity 
x[2]=df.citricacid 
x[3]=df.residualsugar 
x[4]=df.chlorides 
x[5]=df.freeso2 
x[6]=df.totalso2 
x[7]=df.density 
x[8]=df.pH 
x[9]=df.sulphates
x[10]=df.alcohol
for i in range(0,n):   #If quality is less than or equal to 6 then we will make it zero else we will make it one
	if(y[i]<=6):
		y[i]=0
	else:		
		y[i]=1
for i in range(0,11):
	mn=min(x[i])
	mx=max(x[i])    #Using min max scaling on all attributes by setting each attribute equal to (xi-min(x))/(max(x)-min(x))
	for j in range(0,n):
		x[i][j]=1.0*(x[i][j]-mn)/(mx-mn) 
#This is our dataset for Logistic Regression as given in part 1a of the assignment statement
theta=np.zeros(12)
learning_rate=0.5
temp=np.zeros(12)
Y=np.zeros(n)
X=np.zeros([n,11])
Xtest=np.zeros([n//3,11])
Ytest=np.zeros(n//3)
for i in range(0,11):  #Storing both x and y into numpy arrays to make our computations faster and simpler
	for j in range(n//3,2*n//3):
		X[j-n//3][i]=x[i][j]
for i in range(n//3,2*n//3):
	Y[i-n//3]=y[i]
for i in range(0,11):  #Storing both x and y into numpy arrays to make our computations faster and simpler
	for j in range(2*n//3,n):
		X[j-n//3][i]=x[i][j]
for i in range(2*n//3,n):
	Y[i-n//3]=y[i]
for i in range(0,11):  #Storing both x and y into numpy arrays to make our computations faster and simpler
	for j in range(0,n//3):
		Xtest[j][i]=x[i][j]
for i in range(0,n//3):
	Ytest[i]=y[i]
n=2*n//3
rows=n
columns=11
learning_rate=0.5
iterations=10000  #Iterations
theta=np.zeros(11)
for p in range(iterations):
	changes_in_theta=np.zeros(11)  #To simultaneously update the value of thetas as per the logistic regression algorithm
	for i in range(0,n):
		output=np.dot(theta,X[i,:]) 
		output+=1  #Computing 1+theta0x0+theta1x1........
		Ybar=1.0/(1+np.exp(-output))  #Computing the sigmoid function of the above expression
		difference=y[i]-Ybar
		product=np.multiply(X[i,:],difference)  #Multiplying by x[i][j] correspondingly after taking the first derivative
		product/=n
		changes_in_theta=np.add(changes_in_theta,product)  #storing the change 
	step=np.multiply(changes_in_theta,learning_rate)  #Multiplying by the learning rate
	theta=np.add(theta,step)   #updating all the thetas
	print("Iteration Number:",p)  #Printing iteration number
print("The values of gradient descent parameters are ")
print(theta)  #Printing the value of thetas
true_positive=0
true_negative=0
false_positive=0
false_negative=0  #Computing the parameters for calculating accuracy and other accuracy measurement parameters
for i in range(0,n//2):
	output=np.dot(theta,Xtest[i,:])
	output+=1
	if(output>=0 and y[i]==1):
		true_positive+=1
	if(output<0 and y[i]==0):
		true_negative+=1
	if(output>=0 and y[i]==0):
		false_positive+=1
	if(output<0 and y[i]==1):
		false_negative+=1
print("The accuracy from self written logistic regression is ",end='')
print(100.0*(true_positive+true_negative)/(true_positive+true_negative+false_positive+false_negative),end='')
print("%")
logistic_regression=LogisticRegression()  #using the sklearn logistic regression for comparing the results
logistic_regression.fit(X,y)
LogisticRegression(penalty='none',solver='saga')
y_predict=logistic_regression.predict(Xtest)
accuracy=metrics.accuracy_score(Ytest,y_predict)
print("The accuracy from sklearn logistic regression is ",end='')
print(accuracy*100.0,end='')
print("%")

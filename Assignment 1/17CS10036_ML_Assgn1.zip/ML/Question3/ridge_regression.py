#Created By Prakhar Bindal(17CS10036)
#Implementation of ridge regression on max and min error polynomials obtained using best fit curves
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
df=pd.read_csv("train.csv")
x=df.Feature
y=df.Label
learning_rate=0.05
length=float(len(df))
test=[]
train=[]
Lamda=[]  #Maximum error polynomial for train.csv file using ridge regression
N=[]
print("For training data with maximum error polynomial the lambda and cost are given by ")
for lamda in [0.25,0.5,0.75,1]:
	for n in [1]:
		iterations=1000
		coefficients=[]
		for i in range(0,n+1):  #making all the coefficients to be zero
			coefficients.append(0)
		Cost=0
		for i in range(iterations):
			y_prediction=0
			for j in range(0,n+1):
				y_prediction+=coefficients[j]*(x**j)
			cost=sum((y-y_prediction)*(y-y_prediction))
			coefficient_sum=0
			for x in coefficients:
				coefficient_sum+=x*x #	Adding squares of all coefficients as present in the formula of ridge regression
			cost+=lamda*coefficient_sum
			cost/=2*length
			for j in range(0,n+1):
				gradient=2*(x**j)*sum(-y+y_prediction)
				gradient+=2*lamda*coefficients[j]  #differentiation x^2 will yield 2*coefficient*lambda in the expression of ridge regression
				gradient/=(2*length)
				coefficients[j]-=learning_rate*gradient
			Cost=cost 
		train.append(Cost)
		Lamda.append(lamda)
		print(lamda,Cost)
df=pd.read_csv("test.csv")
x=df.Feature
y=df.Label
length=float(len(df))  #Same stuff for test.csv file
print("For test data with maximum error polynomial the lambda and cost are given by ")
for lamda in [0.25,0.5,0.75,1]:
	for n in [1]:
		iterations=1000
		coefficients=[]
		for i in range(0,n+1):
			coefficients.append(0)
		Cost=0
		for i in range(iterations):
			y_prediction=0
			for j in range(0,n+1):
				y_prediction+=coefficients[j]*(x**j)
			cost=sum((y-y_prediction)*(y-y_prediction))
			coefficient_sum=0
			for x in coefficients:
				coefficient_sum+=x*x
			cost+=lamda*coefficient_sum
			cost/=2*length
			for j in range(0,n+1):
				gradient=2*(x**j)*sum(-y+y_prediction)
				gradient+=2*lamda*coefficients[j]
				gradient/=(2*length)
				coefficients[j]-=learning_rate*gradient
			Cost=cost 
		print(lamda,Cost)
		test.append(Cost)
plt.scatter(Lamda,test,color='blue')
plt.xlabel('Value of lambda')
plt.ylabel('Error')
plt.title('Test Data-Polynomial with maximum error(Linear)')
plt.show()
plt.scatter(Lamda,train,color='blue')
plt.xlabel('Value of lambda')
plt.ylabel('Error')
plt.title('Train Data-Polynomial with maximum error(Linear)')
plt.show()
df=pd.read_csv("train.csv")
x=df.Feature
y=df.Label
learning_rate=0.05
length=float(len(df))
test=[]   #for min error polynomial on train.csv file
train=[]
Lamda=[]
N=[]
print("For training data with minimum error polynomial the lambda and cost are given by ")
for lamda in [0.25,0.5,0.75,1]:
	for n in [9]:
		iterations=1000  #same stuff as above
		coefficients=[]
		for i in range(0,n+1):
			coefficients.append(0)
		Cost=0
		for i in range(iterations):
			y_prediction=0
			for j in range(0,n+1):
				y_prediction+=coefficients[j]*(x**j)
			cost=sum((y-y_prediction)*(y-y_prediction))
			coefficient_sum=0
			for x in coefficients:
				coefficient_sum+=x*x
			cost+=lamda*coefficient_sum
			cost/=2*length
			for j in range(0,n+1):
				gradient=2*(x**j)*sum(-y+y_prediction)
				gradient+=2*lamda*coefficients[j]
				gradient/=(2*length)
				coefficients[j]-=learning_rate*gradient
			Cost=cost 
		train.append(Cost)
		print(lamda,Cost)
		Lamda.append(lamda)
df=pd.read_csv("test.csv")
x=df.Feature
y=df.Label
length=float(len(df))  #same stuff as above but for test.csv file in this case
print("For test data with minimum error polynomial the lambda and cost are given by ")
for lamda in [0.25,0.5,0.75,1]:
	for n in [9]:
		iterations=1000
		coefficients=[]
		for i in range(0,n+1):
			coefficients.append(0)
		Cost=0
		for i in range(iterations):
			y_prediction=0
			for j in range(0,n+1):
				y_prediction+=coefficients[j]*(x**j)
			cost=sum((y-y_prediction)*(y-y_prediction))
			coefficient_sum=0
			for x in coefficients:
				coefficient_sum+=x*x
			cost+=lamda*coefficient_sum
			cost/=2*length
			for j in range(0,n+1):
				gradient=2*(x**j)*sum(-y+y_prediction)
				gradient+=2*lamda*coefficients[j]
				gradient/=(2*length)
				coefficients[j]-=learning_rate*gradient
			Cost=cost 
		print(lamda,Cost)
		test.append(Cost)
plt.scatter(Lamda,test,color='red')
plt.xlabel('Value of lambda')
plt.ylabel('Error')
plt.title('Test Data-Polynomial with minimum error(Degree 9)')
plt.show()
plt.scatter(Lamda,train,color='red')
plt.xlabel('Value of lambda')
plt.ylabel('Error')
plt.title('Train Data-Polynomial with minimum error(Degree 9)')
plt.show()
	
#Created By Prakhar Bindal(17CS10036)
#Implementation of lasso regression on max and min error polynomials obtained using best fit curves
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
df=pd.read_csv("train.csv") #reading the train.csv file
x=df.Feature
y=df.Label
learning_rate=0.05
length=float(len(df))
test=[]
train=[]
Lamda=[]
N=[]
print("For training data with maximum error polynomial the lambda and cost are given by ")
for lamda in [0.25,0.5,0.75,1]:  #Iterating over lambdas 
	for n in [1]:  #max error polynomial so degree =1
		iterations=1000
		coefficients=[]
		for i in range(0,n+1):
			coefficients.append(0)
		Cost=0
		for i in range(iterations): #Same linear regression stuff except for the addtional term of lasso regression
			y_prediction=0
			for j in range(0,n+1):
				y_prediction+=coefficients[j]*(x**j)
			cost=sum((y-y_prediction)*(y-y_prediction))
			coefficient_sum=0
			for x in coefficients:
				coefficient_sum+=abs(x)  #Finding absolute sums of coefficients for lasso regression
			cost+=lamda*coefficient_sum  #multiplying the absolute sums by lamda
			cost/=2*length
			for j in range(0,n+1):
				gradient=2*(x**j)*sum(-y+y_prediction)
				if(coefficients[j]>=0):  #As we take absolute terms in lasso regression there will be two cases when we differentiate the function as the modulus function is not differentiable at the neighbourhood of 0
					gradient+=lamda
				else:
					gradient-=lamda #Subtracting if the coefficients is less than zero
				gradient/=(2*length)
				coefficients[j]-=learning_rate*gradient
			Cost=cost 
		train.append(Cost)
		Lamda.append(lamda)
		print(lamda,Cost)
df=pd.read_csv("test.csv")  #same stuff for test.csv file
x=df.Feature
y=df.Label
length=float(len(df))
print("For test data with maximum error polynomial the lambda and cost are given by ")
for lamda in [0.25,0.5,0.75,1]:
	for n in [1]:  #max error polynomial so degree=1
		iterations=1000 
		coefficients=[]
		for i in range(0,n+1):
			coefficients.append(0)
		Cost=0
		for i in range(iterations):
			y_prediction=0
			for j in range(0,n+1):
				y_prediction+=coefficients[j]*(x**j)
			cost=sum((y-y_prediction)*(y-y_prediction))
			coefficient_sum=0
			for x in coefficients:
				coefficient_sum+=abs(x)
			cost+=lamda*coefficient_sum
			cost/=2*length
			for j in range(0,n+1):
				gradient=2*(x**j)*sum(-y+y_prediction)
				if(coefficients[j]>=0):
					gradient+=lamda
				else:
					gradient-=lamda
				gradient/=(2*length)
				coefficients[j]-=learning_rate*gradient
			Cost=cost 
		test.append(Cost)
		print(lamda,Cost)
plt.scatter(Lamda,test,color='blue')
plt.xlabel('Value of lambda')
plt.ylabel('Error')
plt.title('Test Data-Polynomial with maximum error(Linear)')
plt.show()
plt.scatter(Lamda,train,color='blue')
plt.xlabel('Value of lambda')
plt.ylabel('Error')
plt.title('Train Data-Polynomial with maximum error(Linear)')
plt.show()
df=pd.read_csv("train.csv")
x=df.Feature
y=df.Label
learning_rate=0.05
length=float(len(df))
test=[]
train=[]
Lamda=[]
N=[]
print("For training data with minimum error polynomial the lambda and cost are given by ")
for lamda in [0.25,0.5,0.75,1]:
	for n in [9]:  #min error polynomial so degree=9
		iterations=1000
		coefficients=[]
		for i in range(0,n+1):
			coefficients.append(0)
		Cost=0
		for i in range(iterations):
			y_prediction=0
			for j in range(0,n+1):
				y_prediction+=coefficients[j]*(x**j)
			cost=sum((y-y_prediction)*(y-y_prediction))
			coefficient_sum=0
			for x in coefficients:
				coefficient_sum+=abs(x)
			cost+=lamda*coefficient_sum
			cost/=2*length
			for j in range(0,n+1):
				gradient=2*(x**j)*sum(-y+y_prediction)
				if(coefficients[j]>=0):
					gradient+=lamda
				else:
					gradient-=lamda
				gradient/=(2*length)
				coefficients[j]-=learning_rate*gradient
			Cost=cost 
		train.append(Cost)
		Lamda.append(lamda)
		print(lamda,Cost)
df=pd.read_csv("test.csv")
x=df.Feature
y=df.Label
length=float(len(df)) #same stuff for test.csv file
print("For test data with minimum error polynomial the lambda and cost are given by ")
for lamda in [0.25,0.5,0.75,1]:
	for n in [9]: #minerror polynomial so degree=9
		iterations=1000
		coefficients=[]
		for i in range(0,n+1):
			coefficients.append(0)
		Cost=0
		for i in range(iterations):
			y_prediction=0
			for j in range(0,n+1):
				y_prediction+=coefficients[j]*(x**j)
			cost=sum((y-y_prediction)*(y-y_prediction))
			coefficient_sum=0
			for x in coefficients:
				coefficient_sum+=abs(x)
			cost+=lamda*coefficient_sum
			cost/=2*length
			for j in range(0,n+1):
				gradient=2*(x**j)*sum(-y+y_prediction)
				if(coefficients[j]>=0):
					gradient+=lamda
				else:
					gradient-=lamda
				gradient/=(2*length)
				coefficients[j]-=learning_rate*gradient
			Cost=cost 
		test.append(Cost)
		print(lamda,Cost)
for i in range(0,4):
	print(Lamda[i],test[i])
plt.scatter(Lamda,test,color='red')
plt.xlabel('Value of lambda')
plt.ylabel('Error')
plt.title('Test Data-Polynomial with minimum error(Degree 9)')
plt.show()
plt.scatter(Lamda,train,color='red')
plt.xlabel('Value of lambda')
plt.ylabel('Error')
plt.title('Train Data-Polynomial with minimum error(Degree 9)')
plt.show()
	
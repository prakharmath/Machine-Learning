#Created By Prakhar Bindal(17CS10036)
#Plotting the 9 polynomials obtained using best fit
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
df=pd.read_csv("train.csv") #reading the train.csv file
x=df.Feature
y=df.Label
learning_rate=0.05
length=float(len(df))
res=[[0]*10]*10
for n in range(1,10):  #Same linear regression stuff as done in earlier parts
	iterations=1000
	coefficients=[]
	for i in range(0,n+1):
		coefficients.append(0)
	for i in range(iterations):
		y_prediction=0
		for j in range(0,n+1):
			y_prediction+=coefficients[j]*(x**j)
		cost=(1/(2*length))*sum((y-y_prediction)*(y-y_prediction))
		for j in range(0,n+1):
			gradient=(-1/length)*(x**j)*sum(y-y_prediction)
			coefficients[j]-=learning_rate*gradient
	for j in range(0,n+1):		
		res[n][j]=coefficients[j][0]
		print(n,j,res[n][j])
for j in range(1,10):  #Iteration over the degrees of all the 9 polynomials (stored in 2d array res)
	x=np.arange(-1,1,0.000001)
	y=0
	for k in range(0,j+1):
		y+=res[j][k]*(x**k) #Writing the equation of the polynomial for plotting using matplotlib library-
	plt.title('Label v/s Feature Plot for '+str(j)+' degree polynomial')
	plt.xlabel('Feature')
	plt.ylabel('Label')
	plt.plot(x,y)
	plt.show()




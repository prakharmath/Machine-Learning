#Created By Prakhar Bindal(17CS10036)
#Min_cost_function using gradient descent
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
df=pd.read_csv("train.csv")  #Reading the train.csv file using pandas
x=df.Feature
y=df.Label
learning_rate=0.05
length=float(len(df))
res=[[0]*10]*10 #2D array for storing the coefficients of the required 9 polynomials
for n in range(1,10):
	iterations=1000  #iterations
	coefficients=[]
	for i in range(0,n+1): 
		coefficients.append(0) #initially making all the coefficients to be zero
	for i in range(iterations):
		y_prediction=0
		for j in range(0,n+1):
			y_prediction+=coefficients[j]*(x**j)  #Predicting the value by putting the value into the polynomial(a0+a1x+a2x^2...)
		cost=(1/(2*length))*sum((y-y_prediction)*(y-y_prediction)) #Calculating the mean squared error using the formula
		for j in range(0,n+1):
			gradient=(-1/length)*(x**j)*sum(y-y_prediction) #calculating the gradient for each coefficient by partial differentiation of the error with respect to the coefficients
			coefficients[j]-=learning_rate*gradient #Applying the gradient descent
	print("The coefficients of the polynomial of degree "+str(n)+" which minimizes the mean squared error are")
	for j in range(0,n+1):
		res[n][j]=coefficients[j][0]
		print(coefficients[j][0],end=' ')
	print("")
print("\n\n\n")
df=pd.read_csv("test.csv")  #Reading the test.csv file using the pandas library
x=df.Feature
y=df.Label
length=len(x)
for n in range(1,10):
	test_error=0   #Declaring the test_error
	for i in range(length):
		y_predicted=0
		for j in range(0,n+1):
			y_predicted+=res[n][j]*(x[i]**j)  #y_predicted for calculating the squared mean error
		test_error+=(y_predicted-y[i])*(y_predicted-y[i])
	test_error/=2.0*length  #calculation of test_error using appropriate formulas
	print('')
	print('Using the ',end='')
	print(n,end=' ')
	print("degree polynomial as obtained from the minimization of mean squared error,the test error for the test data is ",end='')
	print(test_error)


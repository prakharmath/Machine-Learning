#Created By-Prakhar Bindal(17CS10036)
#Plotting the Feature vs Label data using matplot library
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
df=pd.read_csv("train.csv")  #Reading the train.csv file using pandas
plt.scatter(df.Feature,df.Label,color='blue',marker='o')
plt.title('Label v/s Feature Plot for train data')
plt.xlabel('Feature')
plt.ylabel('Label')
plt.show()
df=pd.read_csv("test.csv")  #Reading the test.csv file using pandas
plt.scatter(df.Feature,df.Label,color='blue',marker='o')
plt.title('Label v/s Feature Plot for test data')
plt.xlabel('Feature')
plt.ylabel('Label')
plt.show()